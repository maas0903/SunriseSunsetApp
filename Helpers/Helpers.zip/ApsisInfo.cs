﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// An apsis event: pericenter (closest approach) or apocenter (farthest distance).
        /// </summary>
        /// <remarks>
        /// For the Moon orbiting the Earth, or a planet orbiting the Sun, an *apsis* is an
        /// event where the orbiting body reaches its closest or farthest point from the primary body.
        /// The closest approach is called *pericenter* and the farthest point is *apocenter*.
        ///
        /// More specific terminology is common for particular orbiting bodies.
        /// The Moon's closest approach to the Earth is called *perigee* and its farthest
        /// point is called *apogee*. The closest approach of a planet to the Sun is called
        /// *perihelion* and the furthest point is called *aphelion*.
        ///
        /// This data structure is returned by #Astronomy.SearchLunarApsis and #Astronomy.NextLunarApsis
        /// to iterate through consecutive alternating perigees and apogees.
        /// </remarks>
        public struct ApsisInfo
        {
            /// <summary>The date and time of the apsis.</summary>
            public readonly AstroTime time;

            /// <summary>Whether this is a pericenter or apocenter event.</summary>
            public readonly ApsisKind kind;

            /// <summary>The distance between the centers of the bodies in astronomical units.</summary>
            public readonly double dist_au;

            /// <summary>The distance between the centers of the bodies in kilometers.</summary>
            public readonly double dist_km;

            internal ApsisInfo(AstroTime time, ApsisKind kind, double dist_au)
            {
                this.time = time;
                this.kind = kind;
                this.dist_au = dist_au;
                this.dist_km = dist_au * Astronomy.KM_PER_AU;
            }
        }
    }
}

