﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Information about the brightness and illuminated shape of a celestial body.
        /// </summary>
        /// <remarks>
        /// Returned by the functions #Astronomy.Illumination and #Astronomy.SearchPeakMagnitude
        /// to report the visual magnitude and illuminated fraction of a celestial body at a given date and time.
        /// </remarks>
        public struct IllumInfo
        {
            /// <summary>The date and time of the observation.</summary>
            public readonly AstroTime time;

            /// <summary>The visual magnitude of the body. Smaller values are brighter.</summary>
            public readonly double mag;

            /// <summary>The angle in degrees between the Sun and the Earth, as seen from the body. Indicates the body's phase as seen from the Earth.</summary>
            public readonly double phase_angle;

            /// <summary>A value in the range [0.0, 1.0] indicating what fraction of the body's apparent disc is illuminated, as seen from the Earth.</summary>
            public readonly double phase_fraction;

            /// <summary>The distance between the Sun and the body at the observation time.</summary>
            public readonly double helio_dist;

            /// <summary>For Saturn, the tilt angle in degrees of its rings as seen from Earth. For all other bodies, 0.</summary>
            public readonly double ring_tilt;

            internal IllumInfo(AstroTime time, double mag, double phase_angle, double helio_dist, double ring_tilt)
            {
                this.time = time;
                this.mag = mag;
                this.phase_angle = phase_angle;
                this.phase_fraction = (1.0 + Math.Cos(Astronomy.DEG2RAD * phase_angle)) / 2.0;
                this.helio_dist = helio_dist;
                this.ring_tilt = ring_tilt;
            }
        }
    }
}

