﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Equatorial angular and cartesian coordinates.
        /// </summary>
        /// <remarks>
        /// Coordinates of a celestial body as seen from the Earth
        /// (geocentric or topocentric, depending on context),
        /// oriented with respect to the projection of the Earth's equator onto the sky.
        /// </remarks>
        public struct Equatorial
        {
            /// <summary>
            /// Right ascension in sidereal hours.
            /// </summary>
            public readonly double ra;

            /// <summary>
            /// Declination in degrees.
            /// </summary>
            public readonly double dec;

            /// <summary>
            /// Distance to the celestial body in AU.
            /// </summary>
            public readonly double dist;

            /// <summary>
            /// Equatorial coordinates in cartesian vector form: x = March equinox, y = June solstice, z = north.
            /// </summary>
            public readonly AstroVector vec;

            internal Equatorial(double ra, double dec, double dist, AstroVector vec)
            {
                this.ra = ra;
                this.dec = dec;
                this.dist = dist;
                this.vec = vec;
            }
        }
    }
}

