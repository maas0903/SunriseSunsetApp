﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Selects the date for which the Earth's equator is to be used for representing equatorial coordinates.
        /// </summary>
        /// <remarks>
        /// The Earth's equator is not always in the same plane due to precession and nutation.
        ///
        /// Sometimes it is useful to have a fixed plane of reference for equatorial coordinates
        /// across different calendar dates.  In these cases, a fixed *epoch*, or reference time,
        /// is helpful. Astronomy Engine provides the J2000 epoch for such cases.  This refers
        /// to the plane of the Earth's orbit as it was on noon UTC on 1 January 2000.
        ///
        /// For some other purposes, it is more helpful to represent coordinates using the Earth's
        /// equator exactly as it is on that date. For example, when calculating rise/set times
        /// or horizontal coordinates, it is most accurate to use the orientation of the Earth's
        /// equator at that same date and time. For these uses, Astronomy Engine allows *of-date*
        /// calculations.
        /// </remarks>
        public enum EquatorEpoch
        {
            /// <summary>
            /// Represent equatorial coordinates in the J2000 epoch.
            /// </summary>
            J2000,

            /// <summary>
            /// Represent equatorial coordinates using the Earth's equator at the given date and time.
            /// </summary>
            OfDate,
        }
    }
}

