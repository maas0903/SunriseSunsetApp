﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

using System.Text;

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// The location of an observer on (or near) the surface of the Earth.
        /// </summary>
        /// <remarks>
        /// This structure is passed to functions that calculate phenomena as observed
        /// from a particular place on the Earth.
        /// </remarks>
        public struct Observer
        {
            /// <summary>
            /// Geographic latitude in degrees north (positive) or south (negative) of the equator.
            /// </summary>
            public readonly double latitude;

            /// <summary>
            /// Geographic longitude in degrees east (positive) or west (negative) of the prime meridian at Greenwich, England.
            /// </summary>
            public readonly double longitude;

            /// <summary>
            /// The height above (positive) or below (negative) sea level, expressed in meters.
            /// </summary>
            public readonly double height;

            /// <summary>
            /// Creates an Observer object.
            /// </summary>
            /// <param name="latitude">Geographic latitude in degrees north (positive) or south (negative) of the equator.</param>
            /// <param name="longitude">Geographic longitude in degrees east (positive) or west (negative) of the prime meridian at Greenwich, England.</param>
            /// <param name="height">The height above (positive) or below (negative) sea level, expressed in meters.</param>
            public Observer(double latitude, double longitude, double height)
            {
                this.latitude = latitude;
                this.longitude = longitude;
                this.height = height;
            }

            /// <summary>
            /// Converts an `Observer` to a string representation like `(N 26.728965, W 093.157562, 1234.567 m)`.
            /// </summary>
            public override string ToString()
            {
                var sb = new StringBuilder();
                sb.Append("(");
                sb.Append(latitude < 0.0 ? "S " : "N ");
                sb.Append(Math.Abs(latitude).ToString("00.000000"));
                sb.Append(", ");
                sb.Append(longitude < 0.0 ? "W " : "E ");
                sb.Append(Math.Abs(longitude).ToString("000.000000"));
                sb.Append(", ");
                sb.Append(height.ToString("0.000"));
                sb.Append(" m)");
                return sb.ToString();
            }
        }
    }
}

