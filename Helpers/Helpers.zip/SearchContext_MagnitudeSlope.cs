﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        internal class SearchContext_MagnitudeSlope : SearchContext
        {
            private readonly Body body;

            public SearchContext_MagnitudeSlope(Body body)
            {
                this.body = body;
            }

            public override double Eval(AstroTime time)
            {
                // The Search() function finds a transition from negative to positive values.
                // The derivative of magnitude y with respect to time t (dy/dt)
                // is negative as an object gets brighter, because the magnitude numbers
                // get smaller. At peak magnitude dy/dt = 0, then as the object gets dimmer,
                // dy/dt > 0.
                const double dt = 0.01;
                AstroTime t1 = time.AddDays(-dt / 2);
                AstroTime t2 = time.AddDays(+dt / 2);
                IllumInfo y1 = Astronomy.Illumination(body, t1);
                IllumInfo y2 = Astronomy.Illumination(body, t2);
                return (y2.mag - y1.mag) / dt;
            }
        }
    }
}

