﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// The dates and times of changes of season for a given calendar year.
        /// Call #Astronomy.Seasons to calculate this data structure for a given year.
        /// </summary>
        public struct SeasonsInfo
        {
            /// <summary>
            /// The date and time of the March equinox for the specified year.
            /// </summary>
            public readonly AstroTime mar_equinox;

            /// <summary>
            /// The date and time of the June soltice for the specified year.
            /// </summary>
            public readonly AstroTime jun_solstice;

            /// <summary>
            /// The date and time of the September equinox for the specified year.
            /// </summary>
            public readonly AstroTime sep_equinox;

            /// <summary>
            /// The date and time of the December solstice for the specified year.
            /// </summary>
            public readonly AstroTime dec_solstice;

            internal SeasonsInfo(AstroTime mar_equinox, AstroTime jun_solstice, AstroTime sep_equinox, AstroTime dec_solstice)
            {
                this.mar_equinox = mar_equinox;
                this.jun_solstice = jun_solstice;
                this.sep_equinox = sep_equinox;
                this.dec_solstice = dec_solstice;
            }
        }
    }
}

