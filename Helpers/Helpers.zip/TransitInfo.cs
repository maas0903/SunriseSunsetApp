﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Information about a transit of Mercury or Venus, as seen from the Earth.
        /// </summary>
        /// <remarks>
        /// Returned by #Astronomy.SearchTransit or #Astronomy.NextTransit to report
        /// information about a transit of Mercury or Venus.
        /// A transit is when Mercury or Venus passes between the Sun and Earth so that
        /// the other planet is seen in silhouette against the Sun.
        ///
        /// The `start` field reports the moment in time when the planet first becomes
        /// visible against the Sun in its background.
        /// The `peak` field reports when the planet is most aligned with the Sun,
        /// as seen from the Earth.
        /// The `finish` field reports the last moment when the planet is visible
        /// against the Sun in its background.
        ///
        /// The calculations are performed from the point of view of a geocentric observer.
        /// </remarks>
        public struct TransitInfo
        {
            /// <summary>Date and time at the beginning of the transit.</summary>
            public AstroTime start;

            /// <summary>Date and time of the peak of the transit.</summary>
            public AstroTime peak;

            /// <summary>Date and time at the end of the transit.</summary>
            public AstroTime finish;

            /// <summary>Angular separation in arcminutes between the centers of the Sun and the planet at time `peak`.</summary>
            public double separation;
        }
    }
}

