﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Information about a solar eclipse as seen by an observer at a given time and geographic location.
        /// </summary>
        /// <remarks>
        /// Returned by #Astronomy.SearchLocalSolarEclipse or #Astronomy.NextLocalSolarEclipse
        /// to report information about a solar eclipse as seen at a given geographic location.
        ///
        /// When a solar eclipse is found, it is classified as partial, annular, or total.
        /// The `kind` field thus holds `EclipseKind.Partial`, `EclipseKind.Annular`, or `EclipseKind.Total`.
        /// A partial solar eclipse is when the Moon does not line up directly enough with the Sun
        /// to completely block the Sun's light from reaching the observer.
        /// An annular eclipse occurs when the Moon's disc is completely visible against the Sun
        /// but the Moon is too far away to completely block the Sun's light; this leaves the
        /// Sun with a ring-like appearance.
        /// A total eclipse occurs when the Moon is close enough to the Earth and aligned with the
        /// Sun just right to completely block all sunlight from reaching the observer.
        ///
        /// The `obscuration` field reports what fraction of the Sun's disc appears blocked
        /// by the Moon when viewed by the observer at the peak eclipse time.
        /// This is a value that ranges from 0 (no blockage) to 1 (total eclipse).
        /// The obscuration value will be between 0 and 1 for partial eclipses and annular eclipses.
        /// The value will be exactly 1 for total eclipses. Obscuration gives an indication
        /// of how dark the eclipse appears.
        ///
        /// There are 5 "event" fields, each of which contains a time and a solar altitude.
        /// Field `peak` holds the date and time of the center of the eclipse, when it is at its peak.
        /// The fields `partial_begin` and `partial_end` are always set, and indicate when
        /// the eclipse begins/ends. If the eclipse reaches totality or becomes annular,
        /// `total_begin` and `total_end` indicate when the total/annular phase begins/ends.
        /// When an event field is valid, the caller must also check its `altitude` field to
        /// see whether the Sun is above the horizon at the time indicated by the `time` field.
        /// See #EclipseEvent for more information.
        /// </remarks>
        public struct LocalSolarEclipseInfo
        {
            /// <summary>The type of solar eclipse: `EclipseKind.Partial`, `EclipseKind.Annular`, or `EclipseKind.Total`.</summary>
            public EclipseKind kind;

            /// <summary>The fraction of the Sun's apparent disc area obscured by the Moon at the eclipse peak.</summary>
            public double obscuration;

            /// <summary>The time and Sun altitude at the beginning of the eclipse.</summary>
            public EclipseEvent partial_begin;

            /// <summary>If this is an annular or a total eclipse, the time and Sun altitude when annular/total phase begins; otherwise invalid.</summary>
            public EclipseEvent total_begin;

            /// <summary>The time and Sun altitude when the eclipse reaches its peak.</summary>
            public EclipseEvent peak;

            /// <summary>If this is an annular or a total eclipse, the time and Sun altitude when annular/total phase ends; otherwise invalid.</summary>
            public EclipseEvent total_end;

            /// <summary>The time and Sun altitude at the end of the eclipse.</summary>
            public EclipseEvent partial_end;
        }
    }
}

