﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Information about a body's rotation axis at a given time.
        /// </summary>
        /// <remarks>
        /// This structure is returned by #Astronomy.RotationAxis to report
        /// the orientation of a body's rotation axis at a given moment in time.
        /// The axis is specified by the direction in space that the body's north pole
        /// points, using angular equatorial coordinates in the J2000 system (EQJ).
        ///
        /// Thus `ra` is the right ascension, and `dec` is the declination, of the
        /// body's north pole vector at the given moment in time. The north pole
        /// of a body is defined as the pole that lies on the north side of the
        /// [Solar System's invariable plane](https://en.wikipedia.org/wiki/Invariable_plane),
        /// regardless of the body's direction of rotation.
        ///
        /// The `spin` field indicates the angular position of a prime meridian
        /// arbitrarily recommended for the body by the International Astronomical
        /// Union (IAU).
        ///
        /// The fields `ra`, `dec`, and `spin` correspond to the variables
        /// α0, δ0, and W, respectively, from
        /// [Report of the IAU Working Group on Cartographic Coordinates and Rotational Elements: 2015](https://astropedia.astrogeology.usgs.gov/download/Docs/WGCCRE/WGCCRE2015reprint.pdf).
        ///
        /// The field `north` is a unit vector pointing in the direction of the body's north pole.
        /// It is expressed in the J2000 mean equator system (EQJ).
        /// </remarks>
        public struct AxisInfo
        {
            /// <summary>The J2000 right ascension of the body's north pole direction, in sidereal hours.</summary>
            public double ra;

            /// <summary>The J2000 declination of the body's north pole direction, in degrees.</summary>
            public double dec;

            /// <summary>Rotation angle of the body's prime meridian, in degrees.</summary>
            public double spin;

            /// <summary>A J2000 dimensionless unit vector pointing in the direction of the body's north pole.</summary>
            public AstroVector north;
        }
    }
}

