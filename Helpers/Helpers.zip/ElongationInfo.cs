﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Contains information about the visibility of a celestial body at a given date and time.
        /// See #Astronomy.Elongation for more detailed information about the members of this structure.
        /// See also #Astronomy.SearchMaxElongation for how to search for maximum elongation events.
        /// </summary>
        public struct ElongationInfo
        {
            /// <summary>The date and time of the observation.</summary>
            public readonly AstroTime time;

            /// <summary>Whether the body is best seen in the morning or the evening.</summary>
            public readonly Visibility visibility;

            /// <summary>The angle in degrees between the body and the Sun, as seen from the Earth.</summary>
            public readonly double elongation;

            /// <summary>The difference between the ecliptic longitudes of the body and the Sun, as seen from the Earth.</summary>
            public readonly double ecliptic_separation;

            internal ElongationInfo(AstroTime time, Visibility visibility, double elongation, double ecliptic_separation)
            {
                this.time = time;
                this.visibility = visibility;
                this.elongation = elongation;
                this.ecliptic_separation = ecliptic_separation;
            }
        }
    }
}

