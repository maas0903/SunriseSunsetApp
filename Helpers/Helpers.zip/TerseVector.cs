﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        internal struct TerseVector
        {
            public double x;
            public double y;
            public double z;

            public TerseVector(double x, double y, double z)
            {
                this.x = x;
                this.y = y;
                this.z = z;
            }

            public static readonly TerseVector Zero = new TerseVector(0.0, 0.0, 0.0);

            public AstroVector ToAstroVector(AstroTime time)
            {
                return new AstroVector(x, y, z, time);
            }

            public static TerseVector operator +(TerseVector a, TerseVector b)
            {
                return new TerseVector(a.x + b.x, a.y + b.y, a.z + b.z);
            }

            public static TerseVector operator -(TerseVector a, TerseVector b)
            {
                return new TerseVector(a.x - b.x, a.y - b.y, a.z - b.z);
            }

            public static TerseVector operator -(TerseVector a)
            {
                return new TerseVector(-a.x, -a.y, -a.z);
            }

            public static TerseVector operator *(double s, TerseVector v)
            {
                return new TerseVector(s * v.x, s * v.y, s * v.z);
            }

            public static TerseVector operator /(TerseVector v, double s)
            {
                return new TerseVector(v.x / s, v.y / s, v.z / s);
            }

            public double Quadrature()
            {
                return x * x + y * y + z * z;
            }

            public double Magnitude()
            {
                return Math.Sqrt(Quadrature());
            }
        }
    }
}

