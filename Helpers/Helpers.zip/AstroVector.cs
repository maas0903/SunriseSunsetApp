﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

using System.Globalization;
using System.Text.RegularExpressions;

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// A 3D Cartesian vector whose components are expressed in Astronomical Units (AU).
        /// </summary>
        public struct AstroVector
        {
            /// <summary>
            /// The Cartesian x-coordinate of the vector in AU.
            /// </summary>
            public double x;

            /// <summary>
            /// The Cartesian y-coordinate of the vector in AU.
            /// </summary>
            public double y;

            /// <summary>
            /// The Cartesian z-coordinate of the vector in AU.
            /// </summary>
            public double z;

            /// <summary>
            /// The date and time at which this vector is valid.
            /// </summary>
            public AstroTime t;

            /// <summary>
            /// Creates an AstroVector.
            /// </summary>
            /// <param name="x">A Cartesian x-coordinate expressed in AU.</param>
            /// <param name="y">A Cartesian y-coordinate expressed in AU.</param>
            /// <param name="z">A Cartesian z-coordinate expressed in AU.</param>
            /// <param name="t">The date and time at which this vector is valid.</param>
            public AstroVector(double x, double y, double z, AstroTime t)
            {
                if (t == null)
                    throw new NullReferenceException("AstroTime parameter is not allowed to be null.");

                this.x = x;
                this.y = y;
                this.z = z;
                this.t = t;
            }

            /// <summary>
            /// Converts the vector to a string of the format (x, y, z, t).
            /// </summary>
            public override string ToString()
            {
                return $"({x:G16}, {y:G16}, {z:G16}, {t})";
            }

            // (0.1428571428571428, 1.333333333333333, 3.846153846153846E-07, 2023-02-14T09:45:30.000Z)
            private static Regex re = new Regex(
                @"^\s*\(\s*                 # (
            ([^\s,]+) \s* , \s*         # x ,
            ([^\s,]+) \s* , \s*         # y ,
            ([^\s,]+) \s* , \s*         # z ,
            ([^\s\)]+) \s* \) \s* $     # t )",
                RegexOptions.Compiled | RegexOptions.CultureInvariant | RegexOptions.IgnorePatternWhitespace
            );

            /// <summary>
            /// Parses a vector from a string as formatted by #AstroVector.ToString.
            /// On success, `vector` receives the vector and the function returns `true`.
            /// Otherwise, `vector` receives the value (0, 0, 0, null) and the function returns `false`.
            /// </summary>
            /// <param name="text">A string of the form "(x, y, z, t)".</param>
            /// <param name="vector">Receives the output vector.</param>
            public static bool TryParse(string text, out AstroVector vector)
            {
                vector = new AstroVector();
                if (text != null)
                {
                    Match m = re.Match(text);
                    if (m.Success)
                    {
                        var styles = NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowExponent;
                        return (
                            double.TryParse(m.Groups[1].Value, styles, CultureInfo.InvariantCulture, out vector.x) &&
                            double.TryParse(m.Groups[2].Value, styles, CultureInfo.InvariantCulture, out vector.y) &&
                            double.TryParse(m.Groups[3].Value, styles, CultureInfo.InvariantCulture, out vector.z) &&
                            AstroTime.TryParse(m.Groups[4].Value, out vector.t)
                        );
                    }
                }
                return false;
            }

            /// <summary>
            /// Calculates the total distance in AU represented by this vector.
            /// </summary>
            /// <returns>The nonnegative length of the Cartisian vector in AU.</returns>
            public double Length()
            {
                return Astronomy.hypot(x, y, z);
            }

#pragma warning disable 1591        // we don't need XML documentation for these operator overloads
            public static AstroVector operator -(AstroVector a)
            {
                return new AstroVector(-a.x, -a.y, -a.z, a.t);
            }

            public static AstroVector operator -(AstroVector a, AstroVector b)
            {
                return new AstroVector(
                    a.x - b.x,
                    a.y - b.y,
                    a.z - b.z,
                    VerifyIdenticalTimes(a.t, b.t)
                );
            }

            public static AstroVector operator +(AstroVector a, AstroVector b)
            {
                return new AstroVector(
                    a.x + b.x,
                    a.y + b.y,
                    a.z + b.z,
                    VerifyIdenticalTimes(a.t, b.t)
                );
            }

            public static double operator *(AstroVector a, AstroVector b)
            {
                // the scalar dot product of two vectors
                VerifyIdenticalTimes(a.t, b.t);
                return (a.x * b.x) + (a.y * b.y) + (a.z * b.z);
            }

            public static AstroVector operator *(double factor, AstroVector a)
            {
                return new AstroVector(
                    factor * a.x,
                    factor * a.y,
                    factor * a.z,
                    a.t
                );
            }

            public static AstroVector operator /(AstroVector a, double denom)
            {
                if (denom == 0.0)
                    throw new ArgumentException("Attempt to divide a vector by zero.");

                return new AstroVector(
                    a.x / denom,
                    a.y / denom,
                    a.z / denom,
                    a.t
                );
            }
#pragma warning restore 1591

            private static AstroTime VerifyIdenticalTimes(AstroTime a, AstroTime b)
            {
                if (a.tt != b.tt)
                    throw new ArgumentException("Attempt to operate on two vectors from different times.");

                // If either time has already had its nutation calculated, retain that work.
                return !double.IsNaN(a.psi) ? a : b;
            }
        }
    }
}

