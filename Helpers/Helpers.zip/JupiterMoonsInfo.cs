﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Holds the positions and velocities of Jupiter's major 4 moons.
        /// </summary>
        /// <remarks>
        /// The #Astronomy.JupiterMoons function returns an object of this type
        /// to report position and velocity vectors for Jupiter's largest 4 moons
        /// Io, Europa, Ganymede, and Callisto. Each position vector is relative
        /// to the center of Jupiter. Both position and velocity are oriented in
        /// the EQJ system (that is, using Earth's equator at the J2000 epoch).
        /// The positions are expressed in astronomical units (AU),
        /// and the velocities in AU/day.
        /// </remarks>
        public struct JupiterMoonsInfo
        {
            /// <summary>The position and velocity of Jupiter's moon Io.</summary>
            public StateVector io;

            /// <summary>The position and velocity of Jupiter's moon Europa.</summary>
            public StateVector europa;

            /// <summary>The position and velocity of Jupiter's moon Ganymede.</summary>
            public StateVector ganymede;

            /// <summary>The position and velocity of Jupiter's moon Callisto.</summary>
            public StateVector callisto;
        }
    }
}

