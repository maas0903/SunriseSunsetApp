﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Information about a lunar eclipse.
        /// </summary>
        /// <remarks>
        /// Returned by #Astronomy.SearchLunarEclipse or #Astronomy.NextLunarEclipse
        /// to report information about a lunar eclipse event.
        /// When a lunar eclipse is found, it is classified as penumbral, partial, or total.
        /// Penumbral eclipses are difficult to observe, because the Moon is only slightly dimmed
        /// by the Earth's penumbra; no part of the Moon touches the Earth's umbra.
        /// Partial eclipses occur when part, but not all, of the Moon touches the Earth's umbra.
        /// Total eclipses occur when the entire Moon passes into the Earth's umbra.
        ///
        /// The `kind` field thus holds `EclipseKind.Penumbral`, `EclipseKind.Partial`,
        /// or `EclipseKind.Total`, depending on the kind of lunar eclipse found.
        ///
        /// The `obscuration` field holds a value in the range [0, 1] that indicates what fraction
        /// of the Moon's apparent disc area is covered by the Earth's umbra at the eclipse's peak.
        /// This indicates how dark the peak eclipse appears. For penumbral eclipses, the obscuration
        /// is 0, because the Moon does not pass through the Earth's umbra. For partial eclipses,
        /// the obscuration is somewhere between 0 and 1. For total lunar eclipses, the obscuration is 1.
        ///
        /// Field `peak` holds the date and time of the center of the eclipse, when it is at its peak.
        ///
        /// Fields `sd_penum`, `sd_partial`, and `sd_total` hold the semi-duration of each phase
        /// of the eclipse, which is half of the amount of time the eclipse spends in each
        /// phase (expressed in minutes), or 0 if the eclipse never reaches that phase.
        /// By converting from minutes to days, and subtracting/adding with `peak`, the caller
        /// may determine the date and time of the beginning/end of each eclipse phase.
        /// </remarks>
        public struct LunarEclipseInfo
        {
            /// <summary>The type of lunar eclipse found.</summary>
            public EclipseKind kind;

            /// <summary>The peak fraction of the Moon's apparent disc that is covered by the Earth's umbra.</summary>
            public double obscuration;

            /// <summary>The time of the eclipse at its peak.</summary>
            public AstroTime peak;

            /// <summary>The semi-duration of the penumbral phase in minutes.</summary>
            public double sd_penum;

            /// <summary>The semi-duration of the partial phase in minutes, or 0.0 if none.</summary>
            public double sd_partial;

            /// <summary>The semi-duration of the total phase in minutes, or 0.0 if none.</summary>
            public double sd_total;

            internal LunarEclipseInfo(EclipseKind kind, double obscuration, AstroTime peak, double sd_penum, double sd_partial, double sd_total)
            {
                this.kind = kind;
                this.obscuration = obscuration;
                this.peak = peak;
                this.sd_penum = sd_penum;
                this.sd_partial = sd_partial;
                this.sd_total = sd_total;
            }
        }
    }
}

