﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Reports the time and geographic location of the peak of a solar eclipse.
        /// </summary>
        /// <remarks>
        /// Returned by #Astronomy.SearchGlobalSolarEclipse or #Astronomy.NextGlobalSolarEclipse
        /// to report information about a solar eclipse event.
        ///
        /// The eclipse is classified as partial, annular, or total, depending on the
        /// maximum amount of the Sun's disc obscured, as seen at the peak location
        /// on the surface of the Earth.
        ///
        /// The `kind` field thus holds `EclipseKind.Partial`, `EclipseKind.Annular`, or `EclipseKind.Total`.
        /// A total eclipse is when the peak observer sees the Sun completely blocked by the Moon.
        /// An annular eclipse is like a total eclipse, but the Moon is too far from the Earth's surface
        /// to completely block the Sun; instead, the Sun takes on a ring-shaped appearance.
        /// A partial eclipse is when the Moon blocks part of the Sun's disc, but nobody on the Earth
        /// observes either a total or annular eclipse.
        ///
        /// If `kind` is `EclipseKind.Total` or `EclipseKind.Annular`, the `latitude` and `longitude`
        /// fields give the geographic coordinates of the center of the Moon's shadow projected
        /// onto the daytime side of the Earth at the instant of the eclipse's peak.
        /// If `kind` has any other value, `latitude` and `longitude` are undefined and should
        /// not be used.
        ///
        /// For total or annular eclipses, the `obscuration` field holds the fraction (0, 1]
        /// of the Sun's apparent disc area that is blocked from view by the Moon's silhouette,
        /// as seen by an observer located at the geographic coordinates `latitude`, `longitude`
        /// at the darkest time `peak`. The value will always be 1 for total eclipses, and less than
        /// 1 for annular eclipses.
        /// For partial eclipses, `obscuration` is undefined and should not be used.
        /// This is because there is little practical use for an obscuration value of
        /// a partial eclipse without supplying a particular observation location.
        /// Developers who wish to find an obscuration value for partial solar eclipses should therefore use
        /// #Astronomy.SearchLocalSolarEclipse and provide the geographic coordinates of an observer.
        /// </remarks>
        public struct GlobalSolarEclipseInfo
        {
            /// <summary>The type of solar eclipse: `EclipseKind.Partial`, `EclipseKind.Annular`, or `EclipseKind.Total`.</summary>
            public EclipseKind kind;

            /// <summary>The peak fraction of the Sun's apparent disc area obscured by the Moon (total and annular eclipses only).</summary>
            public double obscuration;

            /// <summary>
            /// The date and time when the solar eclipse is at its darkest.
            /// This is the instant when the axis of the Moon's shadow cone passes closest to the Earth's center.
            /// </summary>
            public AstroTime peak;

            /// <summary>The distance between the Sun/Moon shadow axis and the center of the Earth, in kilometers.</summary>
            public double distance;

            /// <summary>The geographic latitude at the center of the peak eclipse shadow.</summary>
            public double latitude;

            /// <summary>The geographic longitude at the center of the peak eclipse shadow.</summary>
            public double longitude;
        }
    }
}

