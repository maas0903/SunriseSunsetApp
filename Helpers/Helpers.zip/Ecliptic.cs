﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Ecliptic angular and Cartesian coordinates.
        /// </summary>
        /// <remarks>
        /// Coordinates of a celestial body as seen from the center of the Sun (heliocentric),
        /// oriented with respect to the plane of the Earth's orbit around the Sun (the ecliptic).
        /// </remarks>
        public struct Ecliptic
        {
            /// <summary>
            /// Cartesian ecliptic vector, with components as follows:
            /// x: the direction of the equinox along the ecliptic plane.
            /// y: in the ecliptic plane 90 degrees prograde from the equinox.
            /// z: perpendicular to the ecliptic plane. Positive is north.
            /// </summary>
            public readonly AstroVector vec;

            /// <summary>
            /// Latitude in degrees north (positive) or south (negative) of the ecliptic plane.
            /// </summary>
            public readonly double elat;

            /// <summary>
            /// Longitude in degrees around the ecliptic plane prograde from the equinox.
            /// </summary>
            public readonly double elon;

            internal Ecliptic(AstroVector vec, double elat, double elon)
            {
                this.vec = vec;
                this.elat = elat;
                this.elon = elon;
            }
        }
    }
}

