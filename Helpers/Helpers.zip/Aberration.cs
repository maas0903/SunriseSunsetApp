﻿/*
    Astronomy Engine for C# / .NET.
    https://github.com/cosinekitty/astronomy

    MIT License

    Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

namespace SunriseSunsetApp.Helpers
{
    public static partial class CosineKitty
    {
        /// <summary>
        /// Aberration calculation options.
        /// </summary>
        /// <remarks>
        /// [Aberration](https://en.wikipedia.org/wiki/Aberration_of_light) is an effect
        /// causing the apparent direction of an observed body to be shifted due to transverse
        /// movement of the Earth with respect to the rays of light coming from that body.
        /// This angular correction can be anywhere from 0 to about 20 arcseconds,
        /// depending on the position of the observed body relative to the instantaneous
        /// velocity vector of the Earth.
        ///
        /// Some Astronomy Engine functions allow optional correction for aberration by
        /// passing in a value of this enumerated type.
        ///
        /// Aberration correction is useful to improve accuracy of coordinates of
        /// apparent locations of bodies seen from the Earth.
        /// However, because aberration affects not only the observed body (such as a planet)
        /// but the surrounding stars, aberration may be unhelpful (for example)
        /// for determining exactly when a planet crosses from one constellation to another.
        /// </remarks>
        public enum Aberration
        {
            /// <summary>
            /// Request correction for aberration.
            /// </summary>
            Corrected,

            /// <summary>
            /// Do not correct for aberration.
            /// </summary>
            None,
        }
    }
}

